export const state = {
    activePost: {},
}

export default {
    state,
}
