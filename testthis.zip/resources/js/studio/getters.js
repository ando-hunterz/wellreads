export const getters = {
    activePost(state) {
        return state.activePost
    }
}

export default {
    getters,
}
